import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Metanoia Romanian Baptist Church",
  description: "Bilingual church website for Metanoia Romanian Baptist Church in Seffner, Florida.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ro">
      <body>{children}</body>
    </html>
  );
}
