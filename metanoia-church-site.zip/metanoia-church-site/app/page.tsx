'use client';

import { useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { BookOpen, ChevronRight, Clock, Cross, Globe, HandHeart, Heart, Home, Mail, MapPin, Phone, PlayCircle, Users, Baby, Hammer, Camera } from 'lucide-react';

type Lang = 'en' | 'ro';
type PageKey = 'home'|'about'|'faith'|'pastors'|'ministries'|'sermons'|'events'|'give'|'prayer'|'visit'|'gallery'|'contact';

const images = {
  logo: '/images/logo.png',
  hero: '/images/hero.jpg',
  congregation1: '/images/congregation-1.jpg',
  congregation2: '/images/congregation-2.jpg',
  worship1: '/images/worship-1.jpg',
  preaching: '/images/preaching.jpg',
  children: '/images/children.jpg',
  ministry: '/images/ministry.jpg',
  gallery1: '/images/gallery-1.jpg',
  gallery2: '/images/gallery-2.jpg',
};

const faithSections = {
  en: [
    ['1. The Bible — The Word of God','We believe that the Holy Scriptures of the Old and New Testaments are inspired by the Holy Spirit, are God’s written Word, and are the final, sufficient, and trustworthy authority for faith and life.'],
    ['2. About God','We believe in one God, the Creator, Sustainer, and Ruler of all things, eternally revealed as the Father, the Son, and the Holy Spirit—perfectly one in being and undivided in essence.'],
    ['3. About Humanity','We believe that humanity was created by God in His image, with dignity, moral responsibility, and the calling to live in fellowship with Him and in obedience to His will.'],
    ['4. About Sin','We believe that sin entered through human disobedience and affected all people. Sin separates humanity from God, brings guilt and judgment, and leaves people unable to save themselves.'],
    ['5. About Salvation','We believe that salvation is God’s work of grace through Jesus Christ. It is received by faith, not earned by human merit, and brings forgiveness, reconciliation, and eternal life.'],
    ['6. The New Birth','We believe that regeneration is the work of the Holy Spirit by which a sinner is made new, receives spiritual life, and begins a transformed walk with Christ.'],
    ['7. About the Church','We believe that the church is the community of believers redeemed by Christ, called to worship, fellowship, discipleship, witness, and service under the authority of Scripture.'],
    ['8. About the Ministers of the Church','We believe that God appoints servants for the church’s edification, spiritual oversight, teaching, pastoral care, and orderly ministry according to biblical principles.'],
    ['9. The Ordinances of the New Testament','We believe that the New Testament gives the church two ordinances: believer’s baptism and the Lord’s Supper, both to be practiced in obedience to Christ’s command.'],
    ['10. The Lord’s Day','We believe that the Lord’s Day is set apart for worship, fellowship, spiritual growth, and remembrance of Christ’s resurrection.'],
    ['11. Discipline in the Church','We believe that church discipline is a biblical responsibility intended to preserve holiness, restore the one who has fallen, and protect the testimony of the church.'],
    ['12. About Prayer','We believe that prayer is a God-given means of communion with Him, expressed in faith, humility, thanksgiving, confession, intercession, and dependence on His will.'],
    ['13. About Holiness','We believe that believers are called to a holy life through the work of the Holy Spirit, growing in obedience, purity, love, and separation from sin.'],
    ['14. About Marriage','We believe that marriage is ordained by God and is to be honored as a sacred covenant, lived in faithfulness, purity, love, and mutual responsibility.'],
    ['15. Christian Generosity','We believe that Christian giving is an act of worship and stewardship, expressed joyfully, responsibly, and sacrificially for the work of God and the care of others.'],
    ['16. Our Mediator Before God','We believe that Jesus Christ is our only Mediator before God, our Lord, Savior, High Priest, and Advocate, through whom believers have access to the Father.'],
    ['17. The Perseverance of the Saints in Grace','We believe that God preserves His people in grace and calls believers to remain steadfast in faith, obedience, and hope until the end.'],
    ['18. The Church and the State','We believe that the church and the state have distinct responsibilities. Believers are called to honor lawful authority while remaining faithful to God above all.'],
    ['19. The Life to Come','We believe in the resurrection, the final judgment, eternal life for the redeemed, and eternal separation from God for those who reject His salvation.']
  ],
  ro: [
    ['1. Biblia – Cuvântul lui Dumnezeu','Noi credem şi mărturisim că Sfintele Scripturi ale Vechiului şi Noului Testament sunt inspirate de Duhul Sfânt, sunt Cuvântul lui Dumnezeu scris şi reprezintă autoritatea supremă, suficientă şi fără greş pentru credinţă şi viaţă.'],
    ['2. Despre Dumnezeu','Noi credem şi mărturisim că este un singur Dumnezeu, Creatorul, Susţinătorul şi Stăpânitorul tuturor lucrurilor, descoperit în Sfânta Scriptură ca Tatăl, Fiul şi Duhul Sfânt, desăvârşit una în fiinţă şi nedespărţit în esenţă.'],
    ['3. Despre om','Noi credem şi mărturisim că omul a fost creat de Dumnezeu după chipul Său, cu demnitate, responsabilitate morală şi chemarea de a trăi în părtăşie cu Dumnezeu şi în ascultare de voia Lui.'],
    ['4. Despre păcat','Noi credem şi mărturisim că păcatul a intrat în lume prin neascultare şi a afectat întreaga omenire. Păcatul îl desparte pe om de Dumnezeu, aduce vinovăţie şi judecată şi îl lasă pe om fără putere de a se mântui singur.'],
    ['5. Despre mântuire','Noi credem şi mărturisim că mântuirea este lucrarea harului lui Dumnezeu prin Isus Hristos. Ea este primită prin credinţă, nu câştigată prin merite omeneşti, şi aduce iertare, împăcare şi viaţă veşnică.'],
    ['6. Naşterea din nou','Noi credem şi mărturisim că naşterea din nou este lucrarea Duhului Sfânt prin care păcătosul primeşte viaţă nouă, devine o făptură nouă şi începe o umblare transformată cu Hristos.'],
    ['7. Despre biserică','Noi credem şi mărturisim că biserica este comunitatea celor răscumpăraţi de Hristos, chemată la închinare, părtăşie, ucenicizare, mărturie şi slujire sub autoritatea Scripturii.'],
    ['8. Despre slujitorii bisericii','Noi credem şi mărturisim că Dumnezeu rânduieşte slujitori pentru zidirea bisericii, supraveghere spirituală, învăţătură, păstorire şi desfăşurarea în ordine a lucrării, potrivit principiilor biblice.'],
    ['9. Simbolurile Noului Testament','Noi credem şi mărturisim că Domnul Isus Hristos a lăsat bisericii două simboluri ale Noului Testament: botezul credinciosului şi Cina Domnului, care trebuie practicate în ascultare de porunca Sa.'],
    ['10. Ziua Domnului','Noi credem şi mărturisim că Ziua Domnului este pusă deoparte pentru închinare, părtăşie, creştere spirituală şi aducere aminte de învierea lui Hristos.'],
    ['11. Disciplina în biserică','Noi credem şi mărturisim că disciplina bisericească este o responsabilitate biblică menită să păstreze sfinţenia, să urmărească restaurarea celui căzut şi să protejeze mărturia bisericii.'],
    ['12. Despre rugăciune','Noi credem şi mărturisim că rugăciunea este un mijloc rânduit de Dumnezeu pentru părtăşia cu El, exprimată în credinţă, smerenie, mulţumire, mărturisire, mijlocire şi dependenţă de voia Lui.'],
    ['13. Despre sfinţenie','Noi credem şi mărturisim că credincioşii sunt chemaţi la o viaţă sfântă prin lucrarea Duhului Sfânt, crescând în ascultare, curăţie, dragoste şi despărţire de păcat.'],
    ['14. Despre căsătorie','Noi credem şi mărturisim că căsătoria este rânduită de Dumnezeu şi trebuie onorată ca un legământ sfânt, trăit în credincioşie, curăţie, dragoste şi responsabilitate reciprocă.'],
    ['15. Dărnicia creştină','Noi credem şi mărturisim că dărnicia creştină este un act de închinare şi administrare credincioasă, exprimată cu bucurie, responsabilitate şi jertfă pentru lucrarea lui Dumnezeu şi ajutorarea altora.'],
    ['16. Mijlocitorul nostru în faţa lui Dumnezeu','Noi credem şi mărturisim că Isus Hristos este singurul nostru Mijlocitor înaintea lui Dumnezeu, Domnul, Mântuitorul, Marele Preot şi Apărătorul nostru, prin care avem intrare la Tatăl.'],
    ['17. Păstrarea sfinţilor în har','Noi credem şi mărturisim că Dumnezeu îi păstrează pe ai Săi în har şi îi cheamă pe credincioşi să rămână statornici în credinţă, ascultare şi nădejde până la sfârşit.'],
    ['18. Biserica şi statul','Noi credem şi mărturisim că biserica şi statul au responsabilităţi distincte. Credincioşii sunt chemaţi să respecte autoritatea legitimă, rămânând însă credincioşi lui Dumnezeu mai presus de toate.'],
    ['19. Lucrările vieţii de apoi','Noi credem şi mărturisim în înviere, judecata finală, viaţa veşnică a celor răscumpăraţi şi despărţirea veşnică de Dumnezeu a celor care resping mântuirea Sa.']
  ]
};

const content:any = {
  en: {
    churchName: 'Metanoia Romanian Baptist Church',
    tagline: 'A Christ-centered church for the whole family',
    heroTitle: 'Welcome to Metanoia Romanian Baptist Church',
    ctaPrimary: 'Plan Your Visit',
    ctaSecondary: 'Watch Online',
    serviceTimesTitle: 'Service Times',
    serviceTimes: ['Sunday Worship — 10:00 AM','Sunday Youth Meeting — To Be Updated','Wednesday Prayer & Bible Study — 7:00 PM'],
    quickInfo: [
      { icon: MapPin, title: 'Location', text: '5416 County Rd 579, Seffner, FL 33584' },
      { icon: Phone, title: 'Phone', text: 'Pastor Artur: (612) 644-5890 • Pastor Constantin: (813) 417-3380' },
      { icon: Mail, title: 'Email', text: 'office@metanoiarbct.com • pastor@metanoiarbct.com' },
      { icon: Clock, title: 'Office / Services', text: 'Sunday 10:00 AM • Wednesday 7:00 PM' },
    ],
    aboutTitle: 'About Our Church',
    aboutText: 'Metanoia Romanian Baptist Church exists to glorify God through biblical teaching, prayer, worship, discipleship, and practical love toward people of all ages.',
    welcomeMessage: 'Welcome to the Metanoia Church page. We are here to respond to the spiritual needs of all people interested in God, Holy Scripture, and the church. We invite you to join our church in our effort to worship the Lord together, support missionaries, and raise our children in obedience to the Lord.',
    churchDescription: 'A friendly community of Bible-believing Romanian Christians, who love to worship God together and invite everyone to join us in worship and fellowship.',
    beliefsTitle: 'What We Believe',
    beliefs: ['The Bible is the inspired and final authority for faith and life.','There is one God—Father, Son, and Holy Spirit.','Salvation is by grace through faith in Jesus Christ alone.','The church is called to worship, discipleship, holiness, fellowship, and mission.'],
    visitTitle: 'Plan Your Visit',
    visitText: 'We would love to welcome you in person at Metanoia Romanian Baptist Church. Our services are bilingual, with translation, and we want your first visit to feel clear, warm, and easy to navigate.',
    visitDetails: ['Address: 5416 County Rd 579, Seffner, FL 33584','Sunday worship service begins at 10:00 AM','Wednesday prayer and Bible study begins at 7:00 PM','Youth meeting schedule will be updated soon','Services are bilingual, with translation','Modest, respectful attire is welcome, and visitors are warmly received'],
    sermonsTitle: 'Sermons & Livestreams',
    eventsTitle: 'Events & Weekly Gatherings',
    giveTitle: 'Support the ministry of the church',
    giveText: 'Your generosity supports worship, ministry, missions, children, youth, media, and the future development of Metanoia Romanian Baptist Church.',
    prayerTitle: 'Share a prayer request',
    prayerText: 'If you have a prayer need, we would be honored to pray for you. You may contact the church by email and share your request with the pastoral team.',
    footerText: '© 2026 Metanoia Romanian Baptist Church. All rights reserved.',
  },
  ro: {
    churchName: 'Biserica Baptistă Română Metanoia',
    tagline: 'O biserică centrată pe Hristos pentru întreaga familie',
    heroTitle: 'Bine ați venit la Biserica Baptistă Română Metanoia',
    ctaPrimary: 'Planifică o vizită',
    ctaSecondary: 'Urmărește online',
    serviceTimesTitle: 'Programul serviciilor',
    serviceTimes: ['Serviciu divin duminică — 10:00','Întâlnire tineret — va fi actualizată','Rugăciune și studiu biblic miercuri — 19:00'],
    quickInfo: [
      { icon: MapPin, title: 'Adresă', text: '5416 County Rd 579, Seffner, FL 33584' },
      { icon: Phone, title: 'Telefon', text: 'Pastor Artur: (612) 644-5890 • Pastor Constantin: (813) 417-3380' },
      { icon: Mail, title: 'Email', text: 'office@metanoiarbct.com • pastor@metanoiarbct.com' },
      { icon: Clock, title: 'Program / Servicii', text: 'Duminică 10:00 • Miercuri 19:00' },
    ],
    aboutTitle: 'Despre biserica noastră',
    aboutText: 'Biserica Baptistă Română Metanoia există pentru a-L glorifica pe Dumnezeu prin învățătură biblică, rugăciune, închinare, ucenicizare și dragoste practică față de oameni de toate vârstele.',
    welcomeMessage: 'Bine ati venit pe pagina bisericii Metanoia. Suntem aici ca sa raspundem nevoilor spirituale a tuturor oamenilor interesati de Dumnezeu, sfanta scriptura si biserica. Va invitam sa va alaturati bisericii in efortul nostru de a ne inchina Domnului impreuna, a sustine misionari si a creste copiii nostri in ascultare de Domnul.',
    churchDescription: 'O comunitate prietenoasă de creștini români care cred în Biblie, iubesc să se închine lui Dumnezeu împreună și invită pe oricine să ni se alăture în închinare și părtășie.',
    beliefsTitle: 'Ce credem',
    beliefs: ['Biblia este autoritatea inspirată şi finală pentru credinţă şi viaţă.','Există un singur Dumnezeu: Tatăl, Fiul şi Duhul Sfânt.','Mântuirea este prin har, prin credinţa numai în Isus Hristos.','Biserica este chemată la închinare, ucenicizare, sfinţenie, părtăşie şi misiune.'],
    visitTitle: 'Planifică o vizită',
    visitText: 'Ne-ar face bucurie să vă întâmpinăm personal la Biserica Baptistă Română Metanoia. Serviciile noastre sunt bilingve, cu traducere, iar dorința noastră este ca prima dumneavoastră vizită să fie clară, primitoare și ușor de urmat.',
    visitDetails: ['Adresa: 5416 County Rd 579, Seffner, FL 33584','Serviciul divin de duminică începe la ora 10:00','Rugăciunea și studiul biblic de miercuri încep la ora 19:00','Programul întâlnirii de tineret va fi actualizat în curând','Serviciile sunt bilingve, cu traducere','O ținută modestă și respectuoasă este potrivită, iar vizitatorii sunt primiți cu căldură'],
    sermonsTitle: 'Predici și transmisiuni live',
    eventsTitle: 'Evenimente și întâlniri săptămânale',
    giveTitle: 'Susține lucrarea bisericii',
    giveText: 'Dărnicia dumneavoastră susține închinarea, slujirea, misiunea, copiii, tineretul, media și dezvoltarea viitoare a Bisericii Baptiste Române Metanoia.',
    prayerTitle: 'Trimite o cerere de rugăciune',
    prayerText: 'Dacă aveți o nevoie de rugăciune, ne-ar face bucurie să ne rugăm pentru dumneavoastră. Puteți contacta biserica prin email și puteți transmite cererea către echipa pastorală.',
    footerText: '© 2026 Biserica Baptistă Română Metanoia. Toate drepturile rezervate.',
  }
};

const common = {
  pastors: {
    en: [
      { name:'Pastor Artur Soldau', role:'Senior Pastor', bio:'Born in the Republic of Moldova, Pastor Artur Soldau came to faith in his hometown church in Horgești. After moving to the United States, he served as a youth leader at Grace Romanian Church in Minnesota. He was ordained as pastor at Grace Romanian Church. In 2009 he married Mariana Pașcaru, and together they are raising three wonderful children. He moved from Minnesota to Florida in the fall of 2016 and was elected pastor at Metanoia Church in January 2017, where he has served since as senior pastor.', image: images.preaching },
      { name:'Pastor Constantin Macari', role:'Pastor', bio:'Born in Moldova and raised in a Baptist home and church in the town of Cărpineni, Pastor Constantin Macari received the Lord at the age of 16 and has been involved in ministry ever since. He served as worship leader at Speranța Church in Chișinău, and also as preacher and elder over the missions department. He served for seven years as program director, translator, and worship leader in summer camps with Eurasian Baptist Mission in Moldova. He moved to Florida in 2007 and served at Metanoia Church as deacon, worship leader, and preacher. In January 2026 he was called and ordained to serve as pastor.', image: images.children },
    ],
    ro: [
      { name:'Pastor Artur Soldau', role:'Pastor senior', bio:'Născut în Republica Moldova, Pastorul Artur Soldau s-a întors la Domnul în biserica din localitatea sa natală, Horgești. După mutarea în Statele Unite, a slujit ca lider de tineret la Grace Romanian Church din Minnesota. A fost ordinat ca pastor la Grace Romanian Church. În anul 2009 s-a căsătorit cu Mariana Pașcaru, iar împreună cresc trei copii minunați. S-a mutat din Minnesota în Florida în toamna anului 2016 și a fost ales pastor la Biserica Metanoia în ianuarie 2017, unde slujește de atunci ca pastor senior.', image: images.preaching },
      { name:'Pastor Constantin Macari', role:'Pastor', bio:'Născut de asemenea în Moldova și crescut într-o familie și biserică baptistă din orașul Cărpineni, Pastorul Constantin Macari L-a primit pe Domnul la vârsta de 16 ani și s-a implicat în lucrare de atunci încoace. A slujit ca lider de închinare la Biserica Speranța din Chișinău, precum și ca predicator și prezbiter peste departamentul de misiuni. Timp de șapte ani a slujit ca director de program, traducător și lider de închinare în taberele de vară organizate cu Eurasian Baptist Mission în Moldova. S-a mutat în Florida în 2007 și a slujit în Biserica Metanoia ca diacon, lider de închinare și predicator. În ianuarie 2026 a fost chemat și ordinat pentru slujirea pastorală.', image: images.children },
    ]
  },
  ministries: {
    en: [
      { icon: Cross, name:'Pastor', leader:'Artur Soldau & Constantin Macari', desc:'Pastoral leadership, preaching, counseling, and spiritual care.' },
      { icon: Users, name:'Men', leader:'Constantin Macari', desc:'Bible study, fellowship, mentorship, and service opportunities for men.' },
      { icon: Heart, name:'Women', leader:'Emma Sangeorzan', desc:'Encouragement, discipleship, prayer gatherings, and women’s events.' },
      { icon: Baby, name:'Children', leader:'Lavinia Steopan', desc:'Safe, Bible-based learning and age-appropriate activities for children.' },
      { icon: Users, name:'Youth', leader:'James Hacman', desc:'Discipleship, community, worship, and events for teens and young adults.' },
      { icon: Home, name:'Families', leader:'Artur Soldau', desc:'Marriage, parenting, family support, and fellowship resources.' },
      { icon: HandHeart, name:'Missions', leader:'Ion Cotorobai', desc:'Local outreach, evangelism, missions support, and mercy ministry.' },
      { icon: Camera, name:'Media', leader:'Nicu Robu', desc:'Livestream, sound, slides, website, photography, and communication.' },
      { icon: Hammer, name:'Construction Fund Raising', leader:'Ioan Sangeorzan', desc:'Giving campaigns and project updates for church building needs.' },
    ],
    ro: [
      { icon: Cross, name:'Pastor', leader:'Artur Soldau & Constantin Macari', desc:'Conducere pastorală, predicare, consiliere și îngrijire spirituală.' },
      { icon: Users, name:'Bărbați', leader:'Constantin Macari', desc:'Studiu biblic, părtășie, mentorare și oportunități de slujire pentru bărbați.' },
      { icon: Heart, name:'Femei', leader:'Emma Sangeorzan', desc:'Încurajare, ucenicizare, întâlniri de rugăciune și evenimente pentru femei.' },
      { icon: Baby, name:'Copii', leader:'Lavinia Steopan', desc:'Învățare biblică sigură și activități potrivite vârstei pentru copii.' },
      { icon: Users, name:'Tineret', leader:'James Hacman', desc:'Ucenicizare, comunitate, închinare și evenimente pentru adolescenți și tineri.' },
      { icon: Home, name:'Familii', leader:'Artur Soldau', desc:'Resurse pentru căsnicie, parenting, sprijin pentru familie și părtășie.' },
      { icon: HandHeart, name:'Misiuni', leader:'Ion Cotorobai', desc:'Evanghelizare locală, sprijin misionar și slujire practică.' },
      { icon: Camera, name:'Media', leader:'Nicu Robu', desc:'Transmisiuni live, sunet, proiecție, website, fotografie și comunicare.' },
      { icon: Hammer, name:'Fond de construcție', leader:'Ioan Sangeorzan', desc:'Campanii de dăruire și actualizări despre proiectele de construcție ale bisericii.' },
    ]
  }
};

const sermonItems:any = {
  en: [
    { title:'Live Streams Archive', href:'https://www.youtube.com/@metanoiaromanian/streams', note:'Watch all recent livestreams and archived services' },
    { title:'Sunday Worship Services', href:'https://www.youtube.com/@metanoiaromanian/streams', note:'Main worship services and recent messages' },
    { title:'Special Services', href:'https://www.youtube.com/@metanoiaromanian/streams', note:'Holiday services, guest messages, and special gatherings' },
    { title:'Church YouTube Channel', href:'https://www.youtube.com/@metanoiaromanian/streams', note:'Official Metanoia Romanian Baptist Church livestream page' },
  ],
  ro: [
    { title:'Arhiva transmisiunilor live', href:'https://www.youtube.com/@metanoiaromanian/streams', note:'Urmărește toate transmisiunile recente și serviciile arhivate' },
    { title:'Serviciile divine de duminică', href:'https://www.youtube.com/@metanoiaromanian/streams', note:'Serviciile principale de închinare și mesajele recente' },
    { title:'Servicii speciale', href:'https://www.youtube.com/@metanoiaromanian/streams', note:'Servicii de sărbătoare, mesaje speciale și întâlniri importante' },
    { title:'Canalul YouTube al bisericii', href:'https://www.youtube.com/@metanoiaromanian/streams', note:'Pagina oficială de transmisiuni live a bisericii Metanoia' },
  ]
};

const eventItems:any = {
  en: [
    { title:'Sunday Worship Service', time:'Sunday · 10:00 AM', detail:'Main bilingual worship service with translation.' },
    { title:'Wednesday Prayer & Bible Study', time:'Wednesday · 7:00 PM', detail:'Prayer, teaching, and fellowship in the middle of the week.' },
    { title:'Youth Meeting', time:'To be updated', detail:'Youth fellowship, discipleship, and worship. Please check back soon for the updated schedule.' },
    { title:'Watch Online', time:'YouTube Streams', detail:'Livestreams and archived services are available on the church streams page.' },
  ],
  ro: [
    { title:'Serviciul divin de duminică', time:'Duminică · 10:00', detail:'Serviciul principal de închinare, bilingv, cu traducere.' },
    { title:'Rugăciune și studiu biblic', time:'Miercuri · 19:00', detail:'Rugăciune, învățătură și părtășie în timpul săptămânii.' },
    { title:'Întâlnirea de tineret', time:'Va fi actualizat', detail:'Părtășie, ucenicizare și închinare pentru tineri. Vă rugăm să reveniți pentru programul actualizat.' },
    { title:'Urmărește online', time:'Pagina YouTube Streams', detail:'Transmisiile live și arhiva serviciilor sunt disponibile pe pagina de livestream a bisericii.' },
  ]
};

function SectionTitle({ kicker, title, text }:{ kicker:string; title:string; text?:string }) {
  return <div className='section-title'><div className='kicker'>{kicker}</div><h2>{title}</h2>{text ? <p>{text}</p> : null}</div>;
}
function Card({ children, className='' }:{ children:React.ReactNode; className?:string }) {
  return <div className={`card ${className}`}>{children}</div>;
}

export default function HomePage() {
  const [lang, setLang] = useState<Lang>('ro');
  const [page, setPage] = useState<PageKey>('home');
  const t = useMemo(() => content[lang], [lang]);
  const navItems = [
    ['home', lang === 'en' ? 'Home' : 'Acasă'],
    ['about', lang === 'en' ? 'About' : 'Despre'],
    ['faith', lang === 'en' ? 'Statement of Faith' : 'Mărturisirea de credință'],
    ['pastors', lang === 'en' ? 'Pastors' : 'Pastori'],
    ['ministries', lang === 'en' ? 'Ministries' : 'Departamente'],
    ['sermons', lang === 'en' ? 'Sermons' : 'Predici'],
    ['events', lang === 'en' ? 'Events' : 'Evenimente'],
    ['give', lang === 'en' ? 'Give' : 'Dăruiește'],
    ['prayer', lang === 'en' ? 'Prayer Requests' : 'Cereri de rugăciune'],
    ['visit', lang === 'en' ? 'Visit Us' : 'Vizitează-ne'],
    ['gallery', lang === 'en' ? 'Gallery' : 'Galerie'],
    ['contact', lang === 'en' ? 'Contact' : 'Contact'],
  ] as [PageKey,string][];
  const galleryImages = [images.worship1,images.hero,images.ministry,images.congregation1,images.congregation2,images.gallery1,images.gallery2,images.children];

  const home = <>
    <section className='hero'>
      <img src={images.hero} alt='Metanoia Romanian Baptist Church' className='hero-bg' />
      <div className='hero-overlay' />
      <div className='container hero-inner'>
        <motion.div initial={{opacity:0,y:18}} animate={{opacity:1,y:0}} transition={{duration:.5}}>
          <div className='eyebrow'><BookOpen size={16} /> {lang === 'en' ? 'Bilingual Romanian Baptist Church' : 'Biserică baptistă română bilingvă'}</div>
          <div className='hero-brand'>
            <img src={images.logo} alt='MRBC logo' />
            <div><div style={{fontSize:12,letterSpacing:'.25em',textTransform:'uppercase',color:'#cbd5e1'}}>MRBC</div><div style={{color:'#cbd5e1',fontSize:14}}>Seffner, Florida</div></div>
          </div>
          <h1>{t.heroTitle}</h1>
          <p>{t.welcomeMessage}</p>
          <div className='hero-actions'>
            <button className='primary-btn' onClick={() => setPage('visit')}>{t.ctaPrimary}</button>
            <button className='secondary-btn' onClick={() => setPage('sermons')}>{t.ctaSecondary}</button>
          </div>
        </motion.div>
        <motion.div initial={{opacity:0,y:18}} animate={{opacity:1,y:0}} transition={{duration:.6,delay:.1}}>
          <div className='card card-dark'><div className='card-body card-lg'>
            <h3 style={{marginTop:0}}>{t.serviceTimesTitle}</h3>
            <div className='stack'>
              {t.serviceTimes.map((time:string) => <div key={time} className='service-item dark'><div style={{display:'flex',justifyContent:'space-between',alignItems:'center',gap:10}}><span>{time}</span><ChevronRight size={16} /></div></div>)}
              <div className='service-item dark'><div className='muted'>{lang === 'en' ? 'A warm, family-centered church with Romanian and English language access through live translation.' : 'O biserică primitoare, orientată spre familie, cu acces în limba română și engleză prin traducere live.'}</div></div>
            </div>
          </div></div>
        </motion.div>
      </div>
    </section>

    <section className='section'><div className='container grid-4'>
      {t.quickInfo.map((item:any) => { const Icon = item.icon; return <Card key={item.title}><div className='card-body'><div className='info-item'><div className='icon-box'><Icon size={18} /></div><div><div style={{fontWeight:700}}>{item.title}</div><div className='muted' style={{fontSize:14}}>{item.text}</div></div></div></div></Card>; })}
    </div></section>

    <section className='section'><div className='container grid-2'>
      <Card><div className='card-body card-lg'><SectionTitle kicker={lang === 'en' ? 'About' : 'Despre'} title={t.aboutTitle} text={t.aboutText} /><div className='list-item'>{t.churchDescription}</div></div></Card>
      <Card className='image-card'><img src={images.congregation1} alt='Church congregation' className='image-fill' /></Card>
    </div></section>

    <section className='section'><div className='container'>
      <SectionTitle kicker={lang === 'en' ? 'Beliefs' : 'Credință'} title={t.beliefsTitle} text={lang === 'en' ? 'A short summary of our core biblical convictions.' : 'Un rezumat scurt al convingerilor noastre biblice fundamentale.'} />
      <div className='grid-2'>{t.beliefs.map((belief:string) => <div key={belief} className='belief-item'>{belief}</div>)}</div>
    </div></section>

    <section className='section'><div className='container grid-2-asym'>
      <Card><div className='card-body card-lg'><SectionTitle kicker={lang === 'en' ? 'Latest Sermons' : 'Predici recente'} title={lang === 'en' ? 'Watch and listen to recent messages' : 'Urmărește și ascultă mesaje recente'} text={lang === 'en' ? 'Recent livestreams and services from the church YouTube streams page.' : 'Transmisiuni live și servicii recente de pe pagina YouTube Streams a bisericii.'} />
      <div className='stack'>{sermonItems[lang].map((item:any) => <a key={item.title} href={item.href} className='link-card' target='_blank' rel='noreferrer'><div style={{display:'flex',justifyContent:'space-between',gap:14}}><div><div style={{fontWeight:700}}>{item.title}</div><div className='muted' style={{fontSize:14,marginTop:4}}>{item.note}</div></div><PlayCircle size={20} color='#94a3b8' /></div></a>)}</div>
      </div></Card>
      <Card className='image-card'><img src={images.preaching} alt='Preaching' className='image-fill' /></Card>
    </div></section>

    <section className='section'><div className='container grid-2'>
      <Card><div className='card-body card-lg'><SectionTitle kicker={lang === 'en' ? 'Upcoming Rhythm' : 'Ritmul bisericii'} title={lang === 'en' ? 'Weekly gatherings' : 'Întâlniri săptămânale'} />
      <div className='stack'>{eventItems[lang].map((event:any) => <div key={event.title} className='event-item'><div style={{display:'flex',justifyContent:'space-between',gap:12,alignItems:'center'}}><div style={{fontWeight:700}}>{event.title}</div><div className='badge'>{event.time}</div></div><div className='muted' style={{marginTop:8,fontSize:14,lineHeight:1.6}}>{event.detail}</div></div>)}</div>
      </div></Card>
      <Card className='image-card'><img src={images.worship1} alt='Church worship' className='image-fill' /></Card>
    </div></section>

    <section className='section'><div className='container'>
      <SectionTitle kicker={lang === 'en' ? 'Ministries' : 'Departamente'} title={lang === 'en' ? 'Departments & Ministries' : 'Departamente și slujiri'} />
      <div className='grid-3'>{common.ministries[lang].slice(0,6).map((ministry:any) => { const Icon = ministry.icon; return <Card key={ministry.name}><div className='card-body'><div className='icon-box'><Icon size={18} /></div><h3>{ministry.name}</h3><div className='muted' style={{fontSize:14,lineHeight:1.6}}>{ministry.desc}</div><div style={{marginTop:12,fontWeight:600,fontSize:14}}>{lang === 'en' ? `Leader: ${ministry.leader}` : `Coordonator: ${ministry.leader}`}</div></div></Card>; })}</div>
      <div style={{marginTop:20,textAlign:'center'}}><button className='primary-btn' onClick={() => setPage('ministries')}>{lang === 'en' ? 'View all ministries' : 'Vezi toate departamentele'}</button></div>
    </div></section>

    <section className='section'><div className='container'>
      <SectionTitle kicker={lang === 'en' ? 'Gallery' : 'Galerie'} title={lang === 'en' ? 'Life at Metanoia' : 'Viața bisericii Metanoia'} />
      <div className='gallery-grid'>{galleryImages.slice(0,6).map((src:string) => <Card key={src}><img src={src} alt='Church life' /></Card>)}</div>
    </div></section>
  </>;

  const about = <section className='section'><div className='container'><SectionTitle kicker={lang === 'en' ? 'About' : 'Despre'} title={t.aboutTitle} text={t.aboutText} /><div className='grid-2'><Card><div className='card-body card-lg'><p style={{lineHeight:1.8}}>{t.churchDescription}</p><p style={{lineHeight:1.8}}>{t.welcomeMessage}</p></div></Card><Card className='image-card'><img src={images.congregation2} alt='Church interior' className='image-fill' /></Card></div></div></section>;

  const faith = <section className='section'><div className='container'><SectionTitle kicker={lang === 'en' ? 'Statement of Faith' : 'Mărturisirea de credință'} title={lang === 'en' ? 'Statement of Faith' : 'Mărturisirea de credință'} text={lang === 'en' ? 'Prepared for clear bilingual reading online, based on the Baptist confession used by the church.' : 'Pregătită pentru o lectură clară, bilingvă, în mediul online, pe baza mărturisirii baptiste folosite de biserică.'} /><div className='stack'>{faithSections[lang].map((section:any) => <Card key={section[0]}><div className='card-body'><h3 style={{marginTop:0}}>{section[0]}</h3><p className='muted' style={{lineHeight:1.8,marginBottom:0}}>{section[1]}</p></div></Card>)}</div></div></section>;

  const pastors = <section className='section'><div className='container'><SectionTitle kicker={lang === 'en' ? 'Pastors' : 'Pastori'} title={lang === 'en' ? 'Pastoral Leadership' : 'Conducere pastorală'} /><div className='stack'>{common.pastors[lang].map((pastor:any) => <Card key={pastor.name}><div className='two-col-split'><div className='image-card'><img src={pastor.image} alt={pastor.name} className='image-fill' /></div><div className='card-body card-lg'><h3 style={{marginTop:0}}>{pastor.name}</h3><div className='muted' style={{fontWeight:600,marginBottom:12}}>{pastor.role}</div><p style={{lineHeight:1.8}}>{pastor.bio}</p></div></div></Card>)}</div></div></section>;

  const ministries = <section className='section'><div className='container'><SectionTitle kicker={lang === 'en' ? 'Ministries' : 'Departamente'} title={lang === 'en' ? 'Departments & Ministries' : 'Departamente și slujiri'} /><div className='grid-3'>{common.ministries[lang].map((ministry:any) => { const Icon = ministry.icon; return <Card key={ministry.name}><div className='card-body'><div className='icon-box'><Icon size={18} /></div><h3>{ministry.name}</h3><div className='muted' style={{fontSize:14,lineHeight:1.7}}>{ministry.desc}</div><div style={{marginTop:12,fontWeight:700,fontSize:14}}>{lang === 'en' ? `Leader: ${ministry.leader}` : `Coordonator: ${ministry.leader}`}</div></div></Card>; })}</div></div></section>;

  const sermons = <section className='section'><div className='container'><SectionTitle kicker={lang === 'en' ? 'Teaching' : 'Învățătură'} title={t.sermonsTitle} text={lang === 'en' ? 'Messages and livestream services from the official church YouTube streams page.' : 'Mesaje și servicii transmise pe pagina oficială de live stream YouTube a bisericii.'} /><div className='grid-2-asym'><Card><div className='card-body card-lg'><div className='stack'>{sermonItems[lang].map((item:any) => <a key={item.title} href={item.href} className='link-card' target='_blank' rel='noreferrer'><div style={{display:'flex',justifyContent:'space-between',gap:14}}><div><div style={{fontWeight:700}}>{item.title}</div><div className='muted' style={{fontSize:14,marginTop:4}}>{item.note}</div></div><PlayCircle size={20} color='#94a3b8' /></div></a>)}</div><div className='list-item' style={{marginTop:18}}>{lang === 'en' ? 'Livestream page: youtube.com/@metanoiaromanian/streams' : 'Pagina de livestream: youtube.com/@metanoiaromanian/streams'}</div></div></Card><Card className='image-card'><img src={images.preaching} alt='Preaching' className='image-fill' /></Card></div></div></section>;

  const events = <section className='section'><div className='container'><SectionTitle kicker='Calendar' title={t.eventsTitle} text={lang === 'en' ? 'Regular weekly gatherings and church rhythm.' : 'Întâlnirile regulate ale bisericii și ritmul săptămânal.'} /><div className='grid-4'>{eventItems[lang].map((event:any) => <Card key={event.title}><div className='card-body'><div style={{fontWeight:700}}>{event.title}</div><div className='muted' style={{marginTop:6,fontWeight:600}}>{event.time}</div><div className='muted' style={{marginTop:10,fontSize:14,lineHeight:1.7}}>{event.detail}</div></div></Card>)}</div></div></section>;

  const give = <section className='section'><div className='container grid-2-asym'><div className='card' style={{background:'#0f172a',color:'#fff',borderColor:'#0f172a'}}><div className='card-body card-lg'><SectionTitle kicker={lang === 'en' ? 'Give' : 'Dăruiește'} title={t.giveTitle} text={t.giveText} /><div className='stack'><div className='service-item dark'>{lang === 'en' ? 'Tithes and offerings may be given through Cash App while additional giving options are being organized.' : 'Zeciuielile și darurile pot fi oferite prin Cash App, în timp ce alte opțiuni de dăruire sunt în curs de organizare.'}</div><div className='service-item dark'><div style={{fontWeight:700,marginBottom:6}}>Cash App</div><div>$MetanoiaTampa</div></div><div className='service-item dark'><div style={{fontWeight:700,marginBottom:6}}>{lang === 'en' ? 'Contact for giving' : 'Contact pentru dărnicie'}</div><div>office@metanoiarbct.com<br/>pastor@metanoiarbct.com</div></div></div></div></div><Card className='image-card'><img src={images.ministry} alt='Church ministry' className='image-fill' /></Card></div></section>;

  const prayer = <section className='section'><div className='container grid-2'><Card><div className='card-body card-lg'><SectionTitle kicker={lang === 'en' ? 'Prayer' : 'Rugăciune'} title={t.prayerTitle} text={t.prayerText} /><div className='stack'><div className='email-box'>office@metanoiarbct.com</div><div className='email-box'>pastor@metanoiarbct.com</div><div className='list-item muted'>{lang === 'en' ? 'A future website form can be connected here for direct prayer submissions. For now, email is the primary contact method.' : 'Pe viitor, aici poate fi conectat un formular web pentru transmiterea directă a cererilor de rugăciune. Pentru moment, emailul este metoda principală de contact.'}</div></div></div></Card><Card className='image-card'><img src={images.children} alt='Children ministry' className='image-fill' /></Card></div></section>;

  const visit = <section className='section'><div className='container'><SectionTitle kicker={lang === 'en' ? 'Visit' : 'Vizită'} title={t.visitTitle} text={t.visitText} /><div className='grid-2'><Card><div className='card-body card-lg'><div className='stack'>{t.visitDetails.map((detail:string) => <div key={detail} className='list-item'>{detail}</div>)}</div></div></Card><Card><div className='card-body'><iframe className='map-frame' src='https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3522.878530675375!2d-82.30238290000001!3d27.9976125!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x88c2c956167468cf%3A0x311bc12553f41b6c!2sMetanoia%20Romanian%20Baptist%20Church!5e0!3m2!1sen!2sus!4v1776709117362!5m2!1sen!2sus' height='420' loading='lazy' referrerPolicy='no-referrer-when-downgrade' title='Metanoia Romanian Baptist Church Map' /></div></Card></div></div></section>;

  const gallery = <section className='section'><div className='container'><SectionTitle kicker={lang === 'en' ? 'Gallery' : 'Galerie'} title={lang === 'en' ? 'Church Life' : 'Viața bisericii'} /><div className='grid-2-asym'><div className='gallery-grid'>{galleryImages.slice(0,6).map((src:string) => <Card key={src}><img src={src} alt='Metanoia gallery' /></Card>)}</div><Card><div className='card-body'><div className='footer-title'>Facebook</div><h3 style={{marginTop:0}}>{lang === 'en' ? 'Follow our church page' : 'Urmărește pagina bisericii'}</h3><p className='muted' style={{lineHeight:1.7}}>{lang === 'en' ? 'Stay connected with church updates, livestream announcements, photos, and ministry news through our official Facebook page.' : 'Rămâneți conectați la noutățile bisericii, anunțurile pentru transmisiuni live, fotografii și informațiile despre lucrare prin pagina noastră oficială de Facebook.'}</p><iframe className='social-frame' src='https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2FMetanoiaRoChurch&tabs=timeline&width=500&height=700&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId' height='700' style={{border:'none',overflow:'hidden'}} scrolling='no' allow='autoplay; clipboard-write; encrypted-media; picture-in-picture; web-share' title='Metanoia Romanian Baptist Church Facebook' /></div></Card></div></div></section>;

  const contact = <section className='section'><div className='container'><SectionTitle kicker='Contact' title={lang === 'en' ? 'Get in Touch' : 'Ia legătura cu noi'} /><div className='grid-2'><Card><div className='card-body card-lg'><div className='stack'>{t.quickInfo.map((item:any) => <div key={item.title} className='list-item'><div style={{fontWeight:700}}>{item.title}</div><div className='muted' style={{marginTop:4}}>{item.text}</div></div>)}</div></div></Card><Card className='image-card'><img src={images.worship1} alt='Church worship' className='image-fill' /></Card></div></div></section>;

  const pageNode:any = { home, about, faith, pastors, ministries, sermons, events, give, prayer, visit, gallery, contact }[page];

  return <div className='page-shell'>
    <header className='header'><div className='container header-inner'>
      <button className='brand' onClick={() => setPage('home')}><img src={images.logo} alt='MRBC logo' className='brand-logo' /><div><div className='brand-title'>{t.churchName}</div><div className='brand-subtitle'>{t.tagline}</div></div></button>
      <nav className='nav'>{navItems.map(([key,label]) => <button key={key} className={page === key ? 'active' : ''} onClick={() => setPage(key)}>{label}</button>)}</nav>
      <div className='lang'><button className={lang === 'en' ? 'active' : ''} onClick={() => setLang('en')}><Globe size={16} /> EN</button><button className={lang === 'ro' ? 'active' : ''} onClick={() => setLang('ro')}><Globe size={16} /> RO</button><button className='primary-btn' onClick={() => setPage('visit')}>{t.ctaPrimary}</button></div>
    </div></header>
    <main>{pageNode}</main>
    <footer className='footer'><div className='container footer-inner'>
      <div><div style={{fontSize:18,fontWeight:700}}>{t.churchName}</div><div className='muted' style={{marginTop:8}}>{t.footerText}</div></div>
      <div><div className='footer-title'>{lang === 'en' ? 'Quick Links' : 'Linkuri rapide'}</div><div className='small-links'>{navItems.slice(0,8).map(([key,label]) => <button key={key} style={{background:'transparent',border:'none',textAlign:'left',padding:0,color:'#475569',cursor:'pointer'}} onClick={() => setPage(key)}>{label}</button>)}</div></div>
      <div><div className='footer-title'>{lang === 'en' ? 'Connect' : 'Conectare'}</div><div className='small-links muted'><a href='https://www.facebook.com/MetanoiaRoChurch' target='_blank' rel='noreferrer'>Facebook</a><a href='https://www.youtube.com/@metanoiaromanian/streams' target='_blank' rel='noreferrer'>YouTube Streams</a><a href='https://www.instagram.com/explore/locations/178549832007257/metanoia-romanian-baptist-church/' target='_blank' rel='noreferrer'>Instagram</a><div>office@metanoiarbct.com</div><div>pastor@metanoiarbct.com</div></div></div>
    </div></footer>
  </div>;
}
